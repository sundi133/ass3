Please change the location of the dataset file(shuttle_ext_unique.dat) and excute the program. The code can be executed in eclipse by importing the file to any project and executing directly. Any standard java compilation and execution will do.

Diagrams:
GainRatioDtree is the tree formed by using gain ratio for choosing the attributes.
InfoGainDtree is the tree formed by using information gain for choosing the attributes.